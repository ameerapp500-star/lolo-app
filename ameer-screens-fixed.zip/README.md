# أمير للشاشات (Ameer Screens)

المشروع كامل جاهز للبناء مباشرة (ما يحتاج zip داخل zip ولا patches).

- الواجهة (القوائم): `app/src/main/assets/index.html`
- شاشة السيارة (Android Auto): `app/src/main/java/com/carscreens/app/CarWebScreen.java`
- الواجهة نفسها تنعرض على شاشة السيارة، والتحكم بالقوائم من لمس شاشة السيارة + أزرار (رجوع / رئيسية / ▲ / ▼) فوق.
- البناء: GitHub Actions (`.github/workflows/apk-build.yml`) → artifact اسمه `Ameer-Screens-APK`.
