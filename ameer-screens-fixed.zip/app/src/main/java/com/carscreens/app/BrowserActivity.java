package com.carscreens.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class BrowserActivity extends Activity {
  private EditText entry;

  @Override protected void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    LinearLayout root = new LinearLayout(this);
    root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(18, 18, 18, 18);
    root.setBackgroundColor(0xFF101820);

    TextView title = new TextView(this);
    title.setText("أمير للشاشات - تحكم بمتصفح السيارة");
    title.setTextColor(0xFFFFFFFF);
    title.setTextSize(20);
    title.setPadding(4, 8, 4, 14);
    root.addView(title);

    TextView current = new TextView(this);
    String opened = getIntent().getStringExtra("u");
    current.setText("المتصفح يعمل على شاشة السيارة" + (opened == null ? "" : "\n" + opened));
    current.setTextColor(0xFFB8C7D9);
    current.setTextSize(13);
    current.setPadding(4, 4, 4, 12);
    root.addView(current);

    entry = new EditText(this);
    entry.setSingleLine(true);
    entry.setTextColor(0xFFFFFFFF);
    entry.setHintTextColor(0xFF9EACBA);
    entry.setHint("اكتب أو الصق النص أو الرابط هنا");
    entry.setTextSize(17);
    entry.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
    root.addView(entry, new LinearLayout.LayoutParams(-1, -2));

    LinearLayout row = new LinearLayout(this);
    row.setOrientation(LinearLayout.HORIZONTAL);
    row.addView(button("لصق", v -> paste()), weighted());
    row.addView(button("إرسال النص", v -> send("text")), weighted());
    root.addView(row);

    LinearLayout row2 = new LinearLayout(this);
    row2.setOrientation(LinearLayout.HORIZONTAL);
    row2.addView(button("بحث", v -> send("search")), weighted());
    row2.addView(button("فتح رابط", v -> send("url")), weighted());
    root.addView(row2);

    Button close = button("رجوع", v -> finish());
    root.addView(close, new LinearLayout.LayoutParams(-1, -2));
    setContentView(root);
  }

  private LinearLayout.LayoutParams weighted() {
    return new LinearLayout.LayoutParams(0, -2, 1f);
  }

  private Button button(String label, View.OnClickListener listener) {
    Button b = new Button(this);
    b.setText(label);
    b.setOnClickListener(listener);
    return b;
  }

  private void paste() {
    try {
      ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
      if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
        CharSequence value = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
        if (value != null) entry.setText(value);
        entry.setSelection(entry.length());
      } else {
        Toast.makeText(this, "الحافظة فارغة", Toast.LENGTH_SHORT).show();
      }
    } catch (Exception e) {
      Toast.makeText(this, "تعذّر لصق النص", Toast.LENGTH_SHORT).show();
    }
  }

  private void send(String type) {
    String value = entry.getText().toString();
    if (value.trim().isEmpty()) {
      Toast.makeText(this, "اكتب النص أو الصق الرابط أولاً", Toast.LENGTH_SHORT).show();
      return;
    }
    if ("url".equals(type)) {
      String v = value.trim();
      if (!v.startsWith("http://") && !v.startsWith("https://")) {
        if (v.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$")) value = "https://" + v;
        else value = "https://www.google.com/search?q=" + Uri.encode(v);
      }
    }
    try {
      org.json.JSONObject command = new org.json.JSONObject();
      command.put("type", type);
      command.put("value", value);
      getSharedPreferences("ameer_remote", MODE_PRIVATE).edit()
          .putString("pending", command.toString()).commit();
      Toast.makeText(this, "تم إرسال الأمر إلى شاشة السيارة", Toast.LENGTH_SHORT).show();
    } catch (Exception e) {
      Toast.makeText(this, "تعذّر إرسال الأمر", Toast.LENGTH_SHORT).show();
    }
  }
}
