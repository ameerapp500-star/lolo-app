package com.carscreens.app;
import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
  WebView w; ValueCallback<Uri[]> fcb; View custom; FrameLayout root; boolean folderPickerOnly; boolean m3uPickerOnly; boolean permOnly;
  static final String H = "https://localfile.invalid/";

  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    root = new FrameLayout(this); w = new WebView(this); root.addView(w); setContentView(root);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
    s.setAllowFileAccess(true); s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
    w.addJavascriptInterface(new Bridge(), "Android");
    w.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        String u = r.getUrl().toString();
        if (u.startsWith("http") || u.startsWith("file")) return false;
        try { Intent i = u.startsWith("intent:") ? Intent.parseUri(u, Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, Uri.parse(u)); startActivity(i); } catch (Exception e) {}
        return true;
      }
      @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
        String u = r.getUrl().toString();
        if (!u.startsWith(H)) return null;
        Map<String, String> hd = new HashMap<String, String>();
        hd.put("Access-Control-Allow-Origin", "*");
        try {
          Uri cu = Uri.parse(r.getUrl().getQueryParameter("u"));
          String m = getContentResolver().getType(cu);
          if (m == null) m = "application/octet-stream";
          return new WebResourceResponse(m, null, 200, "OK", hd, getContentResolver().openInputStream(cu));
        } catch (Exception e) {
          return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", hd, new ByteArrayInputStream(new byte[0]));
        }
      }
    });
    w.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
        if (fcb != null) fcb.onReceiveValue(null);
        fcb = cb;
        try { startActivityForResult(p.createIntent(), 1); } catch (Exception e) { fcb = null; return false; }
        return true;
      }
      @Override public void onShowCustomView(View v, CustomViewCallback c) { custom = v; root.addView(v); w.setVisibility(View.GONE); }
      @Override public void onHideCustomView() { root.removeView(custom); custom = null; w.setVisibility(View.VISIBLE); }
    });
    folderPickerOnly = getIntent().getBooleanExtra("ameer_pick_folder", false);
    m3uPickerOnly = getIntent().getBooleanExtra("ameer_pick_m3u", false);
    w.loadUrl("file:///android_asset/index.html");
    if (folderPickerOnly) w.post(() -> launchFolderPicker());
    else if (m3uPickerOnly) w.post(() -> launchM3uPicker());
    else if (getIntent().getBooleanExtra("ameer_request_perm", false)) { permOnly = true; w.post(() -> requestMediaPermissions()); }
  }

  private void launchFolderPicker() {
    try {
      Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
      i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
      startActivityForResult(i, 2);
    } catch (Exception e) { if (folderPickerOnly) finish(); }
  }

  private void launchM3uPicker() {
  try {
    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
    i.addCategory(Intent.CATEGORY_OPENABLE);
    i.setType("*/*");
    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/x-mpegURL", "audio/x-mpegurl", "application/vnd.apple.mpegurl", "text/plain"});
    startActivityForResult(i, 3);
  } catch (Exception e) {
    getSharedPreferences("ameer_m3u", MODE_PRIVATE).edit().putString("pending", "").apply();
    if (m3uPickerOnly) finish();
  }
}

@Override protected void onNewIntent(Intent intent) {
  super.onNewIntent(intent); setIntent(intent);
  if (intent.getBooleanExtra("ameer_pick_folder", false)) { folderPickerOnly = true; launchFolderPicker(); }
  if (intent.getBooleanExtra("ameer_pick_m3u", false)) { m3uPickerOnly = true; launchM3uPicker(); }
  if (intent.getBooleanExtra("ameer_request_perm", false)) { permOnly = true; requestMediaPermissions(); }
}

  class Bridge {
    @JavascriptInterface public void openWeb(String u) {
    CarWebScreen.openWebOnCar(u);
    Intent i = new Intent(MainActivity.this, BrowserActivity.class);
    i.putExtra("u", u);
    startActivity(i);
  }
    @JavascriptInterface public String fetchText(String address) {
    java.net.HttpURLConnection connection = null;
    try {
      java.net.URL u = new java.net.URL(address);
      connection = (java.net.HttpURLConnection) u.openConnection();
      connection.setConnectTimeout(12000); connection.setReadTimeout(20000);
      connection.setRequestProperty("User-Agent", "AmeerScreens/1.0");
      connection.setRequestProperty("Accept", "application/x-mpegURL, audio/x-mpegurl, */*");
      int status = connection.getResponseCode();
      if (status < 200 || status >= 300) return "";
      java.io.InputStream in = connection.getInputStream();
      java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
      byte[] buffer = new byte[8192]; int count; int total = 0;
      while ((count = in.read(buffer)) != -1 && total < 10000000) { out.write(buffer,0,count); total += count; }
      in.close();
      return new String(out.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
    } catch (Exception e) { return ""; }
    finally { if (connection != null) connection.disconnect(); }
  }
  @JavascriptInterface public void openApp(String p) {
      Intent i = getPackageManager().getLaunchIntentForPackage(p);
      if (i != null) startActivity(i);
    }
    @JavascriptInterface public void saveMapApps(String json) {
      try { getSharedPreferences("ameer_maps", MODE_PRIVATE).edit().putString("apps", new JSONArray(json).toString()).apply(); }
      catch (Exception ignored) {}
    }
    @JavascriptInterface public String listApps() {
      JSONArray a = new JSONArray();
      try {
        Intent q = new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
          JSONObject o = new JSONObject();
          o.put("n", r.loadLabel(pm).toString());
          o.put("p", r.activityInfo.packageName);
          a.put(o);
        }
      } catch (Exception e) {}
      return a.toString();
    }
    @JavascriptInterface public void pickFolder() { runOnUiThread(() -> launchFolderPicker()); }
    @JavascriptInterface public String folders() {
      return getSharedPreferences("f", 0).getString("l", "[]");
    }
    @JavascriptInterface public void removeFolder(String t) {
      try {
        SharedPreferences sp = getSharedPreferences("f", 0);
        JSONArray a = new JSONArray(sp.getString("l", "[]")), n = new JSONArray();
        for (int i = 0; i < a.length(); i++) if (!a.getJSONObject(i).getString("t").equals(t)) n.put(a.getJSONObject(i));
        sp.edit().putString("l", n.toString()).apply();
      } catch (Exception e) {}
    }
    @JavascriptInterface public String listDir(String tree, String doc) {
      JSONArray a = new JSONArray();
      try {
        Uri t = Uri.parse(tree);
        if (doc == null || doc.length() == 0) doc = DocumentsContract.getTreeDocumentId(t);
        Uri ch = DocumentsContract.buildChildDocumentsUriUsingTree(t, doc);
        Cursor c = getContentResolver().query(ch, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
        if (c != null) {
          while (c.moveToNext()) {
            JSONObject o = new JSONObject();
            String id = c.getString(0), m = c.getString(2);
            o.put("id", id); o.put("n", c.getString(1)); o.put("m", m);
            o.put("d", DocumentsContract.Document.MIME_TYPE_DIR.equals(m));
            o.put("u", DocumentsContract.buildDocumentUriUsingTree(t, id).toString());
            a.put(o);
          }
          c.close();
        }
      } catch (Exception e) {}
      return a.toString();
    }
    @JavascriptInterface public String listMedia(String kind) {
      final String[] need = Build.VERSION.SDK_INT >= 33
        ? new String[]{"android.permission.READ_MEDIA_AUDIO", "android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES"}
        : new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
      boolean ok = true;
      for (String p : need) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) ok = false;
      if (!ok) {
        runOnUiThread(new Runnable() { public void run() { requestPermissions(need, 3); }});
        return "PERM";
      }
      JSONArray a = new JSONArray();
      try {
        Uri base = kind.equals("audio") ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
          : kind.equals("video") ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
          : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Cursor c = getContentResolver().query(base, new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME}, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC");
        if (c != null) {
          int n = 0;
          while (c.moveToNext() && n++ < 500) {
            JSONObject o = new JSONObject();
            o.put("n", c.getString(1));
            o.put("u", ContentUris.withAppendedId(base, c.getLong(0)).toString());
            a.put(o);
          }
          c.close();
        }
      } catch (Exception e) {}
      return a.toString();
    }
    @JavascriptInterface public String deviceId() {
      String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
      return id == null ? "UNKNOWN" : id.toUpperCase();
    }
    @JavascriptInterface public void copy(String t) {
      ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
      cm.setPrimaryClip(ClipData.newPlainText("id", t));
    }
    @JavascriptInterface public void playVideo(String u) {
    if (CarWebScreen.playVideoOnCar(u)) return;
    Intent i = new Intent(MainActivity.this, VideoActivity.class);
    i.putExtra("u", u);
    startActivity(i);
  }
    @JavascriptInterface public void view(String uri, String mime) {
      try {
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(Uri.parse(uri), mime == null || mime.length() == 0 ? "*/*" : mime);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(i);
      } catch (Exception e) {}
    }
  }

  private void requestMediaPermissions() {
    final String[] need = Build.VERSION.SDK_INT >= 33
      ? new String[]{"android.permission.READ_MEDIA_AUDIO", "android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES"}
      : new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    try { requestPermissions(need, 3); } catch (Exception e) { if (permOnly) finish(); }
  }
  @Override public void onRequestPermissionsResult(int rq, String[] p, int[] g) {
    w.evaluateJavascript("mediaReload()", null);
    if (permOnly) { permOnly = false; finish(); }
  }
  @Override protected void onActivityResult(int rq, int rs, Intent d) {
  if (rq == 3) {
    String playlist = "";
    if (rs == RESULT_OK && d != null && d.getData() != null) {
      try (java.io.InputStream in = getContentResolver().openInputStream(d.getData());
           java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream()) {
        if (in != null) {
          byte[] buffer = new byte[8192]; int n, total = 0;
          while ((n = in.read(buffer)) != -1 && total < 2000000) { out.write(buffer, 0, n); total += n; }
          playlist = out.toString("UTF-8");
        }
      } catch (Exception e) { android.util.Log.e("AmeerScreens", "M3U file read failed", e); }
    }
    getSharedPreferences("ameer_m3u", MODE_PRIVATE).edit().putString("pending", playlist).apply();
    if (m3uPickerOnly) finish();
    return;
  }
    if (rq == 1 && fcb != null) { fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d)); fcb = null; }
    if (rq == 2 && rs == RESULT_OK && d != null && d.getData() != null) {
      try {
        Uri t = d.getData();
        getContentResolver().takePersistableUriPermission(t, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        String id = DocumentsContract.getTreeDocumentId(t);
        String name = id.contains(":") ? id.substring(id.lastIndexOf(':') + 1) : id;
        if (name.length() == 0) name = "الذاكرة";
        SharedPreferences sp = getSharedPreferences("f", 0);
        JSONArray a = new JSONArray(sp.getString("l", "[]"));
        JSONObject o = new JSONObject();
        o.put("t", t.toString()); o.put("n", name);
        a.put(o);
        sp.edit().putString("l", a.toString()).apply();
        if (folderPickerOnly) finish(); else w.evaluateJavascript("fshow()", null);
      } catch (Exception e) { if (folderPickerOnly) finish(); }
    } else if (rq == 2 && folderPickerOnly) { finish(); }
  }
  @Override public void onBackPressed() {
    w.evaluateJavascript("(function(){var a=document.getElementById('app');if(a&&a.style.display!=='none'){home();return 1}return 0})()", new ValueCallback<String>() {
      public void onReceiveValue(String v) { if (!"1".equals(v)) finish(); }
    });
  }
}
