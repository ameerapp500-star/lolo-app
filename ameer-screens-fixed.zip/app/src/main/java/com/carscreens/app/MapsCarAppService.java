package com.carscreens.app;

import android.content.Intent;
import android.net.Uri;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.car.app.CarAppService;
import androidx.car.app.validation.HostValidator;
import androidx.car.app.CarContext;
import androidx.car.app.Session;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.ListTemplate;
import androidx.car.app.model.Row;
import androidx.car.app.model.Template;

/** Template-based in-car menus for Ameer Screens. */
public class MapsCarAppService extends CarAppService {
  private static final String[][] SECTIONS = new String[][] {
    {"yt", "يوتيوب", "قسم يوتيوب"},
    {"web", "متصفح الويب", "قسم التصفح والبحث"},
    {"tv", "تلفزيون", "قوائم وقنوات التلفزيون"},
    {"movies", "الأفلام والمسلسلات", "مكتبة الأفلام والمسلسلات"},
    {"files", "مدير الملفات", "استعراض الملفات والمجلدات"},
    {"video", "مشغل الفيديو", "ملفات الفيديو"},
    {"photos", "معرض الصور", "الصور والألبومات"},
    {"radio", "الراديو", "محطات الراديو"},
    {"music", "الموسيقى", "ملفات الموسيقى"},
    {"news", "الأخبار", "مصادر الأخبار"},
    {"kids", "يوتيوب كدز", "محتوى الأطفال"},
    {"maps", "الخرائط", "تطبيقات الملاحة"},
    {"apps", "تطبيقاتي", "التطبيقات المثبتة على الهاتف"},
    {"mirror", "انعكاس الشاشة", "إعدادات الإرسال والعرض"},
    {"set", "الإعدادات", "إعدادات أمير للشاشات"}
  };

  @Override
  public HostValidator createHostValidator() {
    return new HostValidator.Builder(this)
        .addAllowedHosts(androidx.car.app.R.array.hosts_allowlist_sample)
        .build();
  }

  @Override public Session onCreateSession() { return new AmeerSession(); }

  static class AmeerSession extends Session {
    @Override public Screen onCreateScreen(Intent intent) {
      return new CarWebScreen(getCarContext());
    }
  }

  static class HomeScreen extends Screen {
    HomeScreen(CarContext context) { super(context); }

    @Override public Template onGetTemplate() {
      ItemList.Builder list = new ItemList.Builder();
      for (String[] section : SECTIONS) {
        final String key = section[0];
        final String title = section[1];
        final String subtitle = section[2];
        list.addItem(new Row.Builder()
          .setTitle(title)
          .addText(subtitle)
          .setOnClickListener(() -> getScreenManager().push(new SectionScreen(getCarContext(), key, title)))
          .build());
      }
      return new ListTemplate.Builder()
        .setSingleList(list.build())
        .setTitle("أمير للشاشات")
        .setHeaderAction(Action.APP_ICON)
        .build();
    }
  }

  static class SectionScreen extends Screen {
    private final String key;
    private final String title;

    SectionScreen(CarContext context, String key, String title) {
      super(context);
      this.key = key;
      this.title = title;
    }

    @Override public Template onGetTemplate() {
      if ("maps".equals(key)) return mapsTemplate();

      ItemList.Builder list = new ItemList.Builder();
      list.addItem(new Row.Builder()
        .setTitle(title)
        .addText(sectionDescription(key))
        .build());
      list.addItem(new Row.Builder()
        .setTitle("واجهة السيارة")
        .addText("تم فتح قائمة هذا القسم داخل أمير للشاشات")
        .build());
      list.addItem(new Row.Builder()
        .setTitle("تنبيه التوافق")
        .addText("Android Auto لا يعرض صفحات WebView أو واجهات الهاتف والفيديو مباشرة. يحتاج كل محتوى إلى ربط منفصل بقوالب السيارة المسموحة.")
        .build());

      return new ListTemplate.Builder()
        .setSingleList(list.build())
        .setTitle(title)
        .setHeaderAction(Action.BACK)
        .build();
    }

    private String sectionDescription(String id) {
      for (String[] s : SECTIONS) if (s[0].equals(id)) return s[2];
      return "قسم من تطبيق أمير للشاشات";
    }

    private Template mapsTemplate() {
      ItemList.Builder list = new ItemList.Builder();
      SharedPreferences prefs = getCarContext().getSharedPreferences("ameer_maps", 0);
      int count = 0;
      try {
        JSONArray apps = new JSONArray(prefs.getString("apps", "[]"));
        for (int i = 0; i < apps.length(); i++) {
          JSONObject app = apps.optJSONObject(i);
          if (app == null) continue;
          final String name = app.optString("n", "تطبيق خرائط");
          final String pkg = app.optString("p", "");
          if (pkg.isEmpty()) continue;
          list.addItem(new Row.Builder()
            .setTitle(name)
            .addText("بدء الملاحة")
            .setOnClickListener(() -> openMap())
            .build());
          count++;
        }
      } catch (Exception ignored) { }

      if (count == 0) {
        list.addItem(new Row.Builder()
          .setTitle("ماكو تطبيقات خرائط مضافة")
          .addText("أضف تطبيق الخرائط من قسم الخرائط في أمير على الهاتف")
          .build());
      }
      list.addItem(new Row.Builder()
        .setTitle("بدء الملاحة")
        .addText("فتح تطبيق الملاحة الافتراضي")
        .setOnClickListener(() -> openMap())
        .build());

      return new ListTemplate.Builder()
        .setSingleList(list.build())
        .setTitle("خرائط أمير")
        .setHeaderAction(Action.BACK)
        .build();
    }

    private void openMap() {
      Intent nav = new Intent(CarContext.ACTION_NAVIGATE, Uri.parse("geo:0,0"));
      getCarContext().startCarApp(nav);
    }
  }
}
