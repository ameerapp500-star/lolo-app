package com.carscreens.app;
import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoActivity extends Activity {
  @Override protected void onCreate(Bundle b) {
    super.onCreate(b);
    FrameLayout root = new FrameLayout(this);
    root.setBackgroundColor(0xFF000000);
    final VideoView v = new VideoView(this);
    root.addView(v, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
    setContentView(root);
    MediaController mc = new MediaController(this);
    mc.setAnchorView(v);
    v.setMediaController(mc);
    v.setVideoURI(Uri.parse(getIntent().getStringExtra("u")));
    v.setOnPreparedListener(mp -> v.start());
  }
}
