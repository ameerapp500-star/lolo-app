package com.carscreens.app;

import android.app.Presentation;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.provider.MediaStore;
          import android.provider.DocumentsContract;
import android.provider.Settings;
import android.view.Display;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.InputDevice;
import android.webkit.JsResult;
import android.webkit.JsPromptResult;
import androidx.car.app.model.CarColor;
import androidx.car.app.model.CarIcon;
import androidx.core.graphics.drawable.IconCompat;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.C;
import androidx.media3.common.AudioAttributes;
import android.widget.Toast;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.View;
import android.widget.FrameLayout;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.content.res.AssetFileDescriptor;
import java.io.InputStream;
import androidx.car.app.AppManager;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.SurfaceCallback;
import androidx.car.app.SurfaceContainer;
import androidx.car.app.model.Action;
import androidx.car.app.model.ActionStrip;
import androidx.car.app.model.Template;
import androidx.car.app.navigation.model.NavigationTemplate;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Map;
import java.util.HashMap;

/** Renders the existing Ameer Screens HTML interface on Android Auto's navigation surface. */
public final class CarWebScreen extends Screen {
  private final Handler main = new Handler(Looper.getMainLooper());
  private SurfaceContainer current;
  private VirtualDisplay virtualDisplay;
  private Presentation presentation;
  private WebView web;
private FrameLayout root;
private PlayerView playerView;
private ExoPlayer carPlayer;
  private int scrollX, scrollY;
  private View customView;
  private WebChromeClient.CustomViewCallback customCb;
  private static final String INDEX = "file:///android_asset/index.html";
            private static volatile CarBridge activeBridge;

  private final SurfaceCallback surfaceCallback = new SurfaceCallback() {
    @Override public void onSurfaceAvailable(SurfaceContainer c) {
      current = c;
      main.post(() -> attach(c));
    }
    @Override public void onSurfaceDestroyed(SurfaceContainer c) {
      main.post(() -> detach());
    }
    @Override public void onClick(float x, float y) {
      main.post(() -> dispatchTap(x, y));
    }
    @Override public void onScroll(float dx, float dy) {
      main.post(() -> scrollContent(dx, dy));
    }
    @Override public void onFling(float vx, float vy) {
      main.post(() -> flingContent(vx, vy));
    }
  };

  CarWebScreen(CarContext context) {
    super(context);
    getCarContext().getCarService(AppManager.class).setSurfaceCallback(surfaceCallback);
  }

  private void attach(SurfaceContainer c) {
    detach();
    Surface surface = c.getSurface();
    if (surface == null || !surface.isValid()) return;
    try {
      DisplayManager dm = (DisplayManager) getCarContext().getSystemService(Context.DISPLAY_SERVICE);
      virtualDisplay = dm.createVirtualDisplay("AmeerScreensCar", c.getWidth(), c.getHeight(),
          c.getDpi(), surface, DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION);
      if (virtualDisplay == null) return;
      Display display = virtualDisplay.getDisplay();
      presentation = new Presentation(getCarContext(), display);
      web = new WebView(getCarContext()) {
        @Override public boolean onCheckIsTextEditor() { return false; }
        @Override public InputConnection onCreateInputConnection(EditorInfo outAttrs) { return null; }
      };
                web.setFocusable(true);
                web.setFocusableInTouchMode(true);
root = new FrameLayout(getCarContext());
playerView = new PlayerView(getCarContext());
playerView.setUseController(true);
playerView.setVisibility(View.GONE);
      WebSettings s = web.getSettings();
      s.setJavaScriptEnabled(true);
      s.setDomStorageEnabled(true);
      s.setMediaPlaybackRequiresUserGesture(false);
      s.setAllowFileAccess(true);
      s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
      CarBridge bridge = new CarBridge(getCarContext(), web, main, playerView);
                activeBridge = bridge;
                web.addJavascriptInterface(bridge, "Android");
      web.setWebChromeClient(new WebChromeClient() {
        @Override public boolean onJsAlert(WebView v, String url, String message, JsResult result) { result.confirm(); return true; }
        @Override public boolean onJsConfirm(WebView v, String url, String message, JsResult result) { result.cancel(); return true; }
        @Override public boolean onJsPrompt(WebView v, String url, String message, String def, JsPromptResult result) { result.cancel(); return true; }
        @Override public void onShowCustomView(View v, WebChromeClient.CustomViewCallback cb) { showCustomView(v, cb); }
        @Override public void onHideCustomView() { hideCustomView(); }
      });
      web.setWebViewClient(new WebViewClient() {
        @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
          String u = request.getUrl().toString();
          if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("file:")) return false;
          if (u.startsWith("intent:") && onLocalPage()) launchPhoneIntent(u);
          return true;
        }
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
          String address = request.getUrl().toString();
          if (!address.startsWith("https://localfile.invalid/")) return null;
          Map<String,String> headers = new HashMap<>();
          headers.put("Access-Control-Allow-Origin", "*");
          headers.put("Accept-Ranges", "bytes");
          AssetFileDescriptor afd = null;
          try {
            String raw = Uri.parse(address).getQueryParameter("u");
            if (raw == null) throw new IllegalArgumentException("Missing media URI");
            Uri source = Uri.parse(raw);
            String mime = getCarContext().getContentResolver().getType(source);
            if (mime == null) mime = "application/octet-stream";
            afd = getCarContext().getContentResolver().openAssetFileDescriptor(source, "r");
            if (afd == null) throw new IllegalStateException("Cannot open media descriptor");
            long total = afd.getLength();
            String range = request.getRequestHeaders().get("Range");
            if (range != null && total > 0) {
              java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("bytes=(\\d+)-(\\d*)").matcher(range);
              if (matcher.matches()) {
                long start = Long.parseLong(matcher.group(1));
                long end = matcher.group(2).isEmpty() ? total - 1 : Math.min(total - 1, Long.parseLong(matcher.group(2)));
                if (start >= total || end < start) {
                  headers.put("Content-Range", "bytes */" + total);
                  afd.close();
                  return new WebResourceResponse(mime, null, 416, "Range Not Satisfiable", headers, new java.io.ByteArrayInputStream(new byte[0]));
                }
                long remaining = end - start + 1;
                InputStream stream = afd.createInputStream();
                long skipped = 0; while (skipped < start) { long n = stream.skip(start - skipped); if (n <= 0) break; skipped += n; }
                final AssetFileDescriptor owned = afd;
                InputStream bounded = new java.io.FilterInputStream(stream) {
                  long left = remaining;
                  @Override public int read() throws java.io.IOException { if (left <= 0) return -1; int v = super.read(); if (v >= 0) left--; return v; }
                  @Override public int read(byte[] b, int off, int len) throws java.io.IOException { if (left <= 0) return -1; int n = super.read(b, off, (int)Math.min(len, left)); if (n > 0) left -= n; return n; }
                  @Override public void close() throws java.io.IOException { try { super.close(); } finally { owned.close(); } }
                };
                headers.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
                headers.put("Content-Length", String.valueOf(remaining));
                return new WebResourceResponse(mime, null, 206, "Partial Content", headers, bounded);
              }
            }
            InputStream stream = afd.createInputStream();
            final AssetFileDescriptor owned = afd;
            InputStream managed = new java.io.FilterInputStream(stream) {
              @Override public void close() throws java.io.IOException { try { super.close(); } finally { owned.close(); } }
            };
            if (total > 0) headers.put("Content-Length", String.valueOf(total));
            return new WebResourceResponse(mime, null, 200, "OK", headers, managed);
          } catch (Exception e) {
            try { if (afd != null) afd.close(); } catch (Exception ignored) {}
            try {
              String raw = Uri.parse(address).getQueryParameter("u");
              InputStream fallback = getCarContext().getContentResolver().openInputStream(Uri.parse(raw));
              return new WebResourceResponse("application/octet-stream", null, 200, "OK", headers, fallback);
            } catch (Exception ignored) {
              return new WebResourceResponse("text/plain","utf-8",404,"Not Found",headers,new java.io.ByteArrayInputStream(new byte[0]));
            }
          }
        }
        @Override public void onPageFinished(WebView view, String url) {
          super.onPageFinished(view, url);
          installCarKeyboard(view);
        }
      });
      root.addView(web, new FrameLayout.LayoutParams(-1, -1));
root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
presentation.setContentView(root);
      presentation.show();
      web.loadUrl("file:///android_asset/index.html");
    } catch (Throwable t) { Log.e("AmeerCarWeb", "Failed to attach WebView to car surface", t); detach(); }
  }

  private void installCarKeyboard(WebView view) {
    String js = "(function(){"
      + "if(window.__ameerCarKeyboardInstalled)return;window.__ameerCarKeyboardInstalled=true;"
      + "var active=null,shift=false,symbols=false,arabic=true;"
      + "var st=document.createElement('style');"
      + "st.textContent='#ameer-car-kb{position:fixed;z-index:2147483647;left:0;right:0;bottom:0;background:rgba(15,18,24,.98);padding:6px;display:none;max-height:48vh;overflow:auto;border-top:2px solid #4b8cff;font-family:Arial}#ameer-car-kb .r{display:flex;gap:3px;margin:3px 0}#ameer-car-kb button{flex:1;min-width:0;height:38px;border:0;border-radius:6px;background:#343b49;color:white;font-size:16px;font-weight:bold}#ameer-car-kb button.a{background:#1769aa}';"
      + "document.head.appendChild(st);var kb=document.createElement('div');kb.id='ameer-car-kb';"
      + "function put(v){if(!active)return;try{if(active.isContentEditable)document.execCommand('insertText',false,v);else{var a=active.selectionStart==null?active.value.length:active.selectionStart,b=active.selectionEnd==null?a:active.selectionEnd;if(active.setRangeText)active.setRangeText(v,a,b,'end');else active.value=(active.value||'')+v;active.dispatchEvent(new Event('input',{bubbles:true}));active.dispatchEvent(new Event('change',{bubbles:true}));}}catch(e){}active.focus();}"
      + "function draw(){kb.innerHTML='';var rows=symbols?[['1','2','3','4','5','6','7','8','9','0'],['@','#','$','%','&','-','+','(',')','/'],['*',';','!', '?',':','_','.'],['ABC','⌫','مسافة','↵','لصق','إخفاء']]:arabic?[['١','٢','٣','٤','٥','٦','٧','٨','٩','٠'],['ض','ص','ث','ق','ف','غ','ع','ه','خ','ح','ج'],['ش','س','ي','ب','ل','ا','ت','ن','م','ك'],['ئ','ء','ؤ','ر','لا','ى','ة','و','ز','ظ'],['EN','?123','مسافة','⌫','↵','لصق','إخفاء']]:[['1','2','3','4','5','6','7','8','9','0'],['q','w','e','r','t','y','u','i','o','p'],['a','s','d','f','g','h','j','k','l'],['⇧','z','x','c','v','b','n','m','⌫'],['عربي','?123','مسافة','-','_','.','@','↵','لصق','إخفاء']];"
      + "rows.forEach(function(row){var r=document.createElement('div');r.className='r';row.forEach(function(k){var b=document.createElement('button');b.textContent=k;if(['لصق','إخفاء','↵'].includes(k))b.className='a';b.addEventListener('pointerdown',function(e){e.preventDefault();});b.addEventListener('click',function(){if(k==='إخفاء'){kb.style.display='none';return;}if(k==='لصق'){try{var t=window.Android&&Android.pasteClipboard?Android.pasteClipboard():'';if(t)put(t);}catch(e){}return;}if(k==='مسافة'){put(' ');return;}if(k==='↵'){put(active&&active.tagName==='TEXTAREA'?'\\n':' ');return;}if(k==='⌫'){if(!active)return;try{if(active.isContentEditable)document.execCommand('delete',false,null);else{var x=active.selectionStart==null?active.value.length:active.selectionStart,y=active.selectionEnd==null?x:active.selectionEnd;if(x===y&&x>0)x--;active.setRangeText('',x,y,'end');active.dispatchEvent(new Event('input',{bubbles:true}));}}catch(e){}active.focus();return;}if(k==='عربي'){arabic=true;symbols=false;draw();return;}if(k==='EN'){arabic=false;symbols=false;draw();return;}if(k==='⇧'){shift=!shift;draw();return;}if(k==='?123'){symbols=true;draw();return;}if(k==='ABC'){symbols=false;draw();return;}put(shift?k.toUpperCase():k);if(shift){shift=false;draw();}});r.appendChild(b);});kb.appendChild(r);});}"
      + "draw();document.body.appendChild(kb);function fieldOf(n){if(!n)return null;return n.closest&&n.closest('input:not([type=file]):not([type=hidden]),textarea,[contenteditable=true],[role=textbox],[role=searchbox]');}function activate(t){if(!t)return;active=t;kb.style.display='block';try{t.focus({preventScroll:true});}catch(e){try{t.focus();}catch(x){}}setTimeout(function(){try{t.scrollIntoView({block:'center'});}catch(e){}},80);}document.addEventListener('pointerdown',function(e){var t=fieldOf(e.target);if(t){try{t.setAttribute('inputmode','none');}catch(x){}}},true);['focusin','click','touchend','mousedown'].forEach(function(ev){document.addEventListener(ev,function(e){var t=fieldOf(e.target);if(t)activate(t);},true);});"
      + "document.addEventListener('click',function(e){if(e.target&&e.target.closest&&e.target.closest('a'))kb.style.display='none';},true);"
                + "if(window.Android&&Android.pollRemoteCommand&&!window.__ameerRemotePoll){window.__ameerRemotePoll=true;setInterval(function(){try{var raw=Android.pollRemoteCommand();if(!raw)return;var c=JSON.parse(raw);if(c.type==='url'){kb.style.display='none';window.location.href=c.value;return;}var t=active||fieldOf(document.activeElement);if(!t){var list=document.querySelectorAll('input:not([type=hidden]):not([type=file]),textarea,[contenteditable=true],[role=textbox],[role=searchbox]');for(var i=0;i<list.length;i++){if(list[i].getClientRects().length){t=list[i];break;}}}if(c.type==='search'){kb.style.display='none';if(t){active=t;put(c.value);try{var f=t.form||(t.closest?t.closest('form'):null);if(f){if(f.requestSubmit)f.requestSubmit();else f.submit();}else t.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));}catch(e){}}else{window.location.href='https://www.google.com/search?q='+encodeURIComponent(c.value);}return;}if(t){kb.style.display='none';active=t;put(c.value);}else{window.location.href='https://www.google.com/search?q='+encodeURIComponent(c.value);}}catch(e){}},450);}"
      + "})();";
    view.evaluateJavascript(js, null);
  }

  static boolean openWebOnCar(String url) {
    CarBridge bridge = activeBridge;
    if (bridge == null) return false;
    bridge.openWebOnCar(url);
    return true;
  }

  static boolean playVideoOnCar(String url) {
    CarBridge bridge = activeBridge;
    if (bridge == null) return false;
    bridge.playVideo(url);
    return true;
  }

  private void detach() {
              CarBridge oldBridge = activeBridge;
              activeBridge = null;
              if (oldBridge != null) oldBridge.release();
    try { if (web != null) { web.stopLoading(); web.destroy(); } } catch (Exception ignored) {}
    web = null;
customView = null; customCb = null;
try { if (carPlayer != null) { carPlayer.release(); carPlayer = null; } } catch (Exception ignored) {}
playerView = null; root = null;
    try { if (presentation != null) presentation.dismiss(); } catch (Exception ignored) {}
    presentation = null;
    try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
    virtualDisplay = null;
  }

  private boolean onLocalPage() {
    try {
      String u = web == null ? null : web.getUrl();
      return u != null && u.startsWith("file:///android_asset/");
    } catch (Exception e) { return false; }
  }

  private float scaleX(float v) {
    return (current == null || web == null || web.getWidth() <= 0) ? v : v * web.getWidth() / Math.max(1f, current.getWidth());
  }

  private float scaleY(float v) {
    return (current == null || web == null || web.getHeight() <= 0) ? v : v * web.getHeight() / Math.max(1f, current.getHeight());
  }

  /** Tap from the car touch screen. Our own HTML lists get a direct DOM click; other pages get a real touch. */
  private void dispatchTap(float x, float y) {
    if (presentation == null || web == null) return;
    final float sx = scaleX(x), sy = scaleY(y);
    if (web.getVisibility() == View.VISIBLE && onLocalPage()) {
      String js = "(function(){var r=window.devicePixelRatio||1,x=" + sx + "/r,y=" + sy + "/r;"
        + "var e=document.elementFromPoint(x,y);if(!e)return 'none';"
        + "var t=(e.tagName||'').toUpperCase();if(t==='AUDIO'||t==='VIDEO'||t==='IFRAME')return 'native';"
        + "e.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y}));return 'ok';})()";
      web.evaluateJavascript(js, v -> { if (v != null && v.contains("native")) sendTouchTap(sx, sy); });
      return;
    }
    sendTouchTap(sx, sy);
  }

  private void sendTouchTap(final float sx, final float sy) {
    if (presentation == null) return;
    final long t = android.os.SystemClock.uptimeMillis();
    MotionEvent down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, sx, sy, 0);
    down.setSource(InputDevice.SOURCE_TOUCHSCREEN);
    presentation.getWindow().getDecorView().dispatchTouchEvent(down);
    down.recycle();
    main.postDelayed(() -> {
      if (presentation == null) return;
      MotionEvent up = MotionEvent.obtain(t, android.os.SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, sx, sy, 0);
      up.setSource(InputDevice.SOURCE_TOUCHSCREEN);
      presentation.getWindow().getDecorView().dispatchTouchEvent(up);
      up.recycle();
    }, 60);
  }

  /** Drag on the car touch screen: scroll the page directly (smooth, no fake gestures). */
  private void scrollContent(float dx, float dy) {
    if (web == null || web.getVisibility() != View.VISIBLE) return;
    web.scrollBy(Math.round(scaleX(dx)), Math.round(scaleY(dy)));
  }

  private void flingContent(float vx, float vy) {
    if (web == null || web.getVisibility() != View.VISIBLE) return;
    web.flingScroll(Math.round(-scaleX(vx)), Math.round(-scaleY(vy)));
  }

  private void pageScroll(int dir) {
    if (web == null || web.getVisibility() != View.VISIBLE) return;
    web.evaluateJavascript("window.scrollBy({top:" + dir + "*Math.round(window.innerHeight*0.6),behavior:'smooth'})", null);
  }

  private void launchPhoneIntent(String uri) {
    try {
      Intent in = Intent.parseUri(uri, Intent.URI_INTENT_SCHEME);
      in.setComponent(null);
      in.setSelector(null);
      in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      getCarContext().startActivity(in);
    } catch (Exception e) { Log.e("AmeerCarWeb", "Intent launch failed", e); }
  }

  private void showCustomView(View v, WebChromeClient.CustomViewCallback cb) {
    if (root == null || web == null) {
      try { cb.onCustomViewHidden(); } catch (Exception ignored) {}
      return;
    }
    if (customView != null) exitCustomView();
    customView = v;
    customCb = cb;
    root.addView(v, new FrameLayout.LayoutParams(-1, -1));
    web.setVisibility(View.GONE);
  }

  private void hideCustomView() {
    if (customView == null) return;
    try { if (root != null) root.removeView(customView); } catch (Exception ignored) {}
    customView = null;
    customCb = null;
    if (web != null) web.setVisibility(View.VISIBLE);
  }

  private void exitCustomView() {
    WebChromeClient.CustomViewCallback cb = customCb;
    hideCustomView();
    try { if (cb != null) cb.onCustomViewHidden(); } catch (Exception ignored) {}
  }

  private void goBackFromCar() {
    if (customView != null) { exitCustomView(); return; }
    CarBridge bridge = activeBridge;
    if (bridge != null && bridge.hidePlayerIfVisible()) return;
    if (web == null) return;
    if (onLocalPage()) { web.evaluateJavascript("carBack()", null); return; }
    if (web.canGoBack()) web.goBack(); else web.loadUrl(INDEX);
  }

  private void goHomeFromCar() {
    if (customView != null) exitCustomView();
    CarBridge bridge = activeBridge;
    if (bridge != null) bridge.hidePlayerIfVisible();
    if (web == null) return;
    if (onLocalPage()) web.evaluateJavascript("home()", null); else web.loadUrl(INDEX);
  }

  private Action iconAction(int resId, androidx.car.app.model.OnClickListener listener) {
    CarIcon icon = new CarIcon.Builder(IconCompat.createWithResource(getCarContext(), resId))
        .setTint(CarColor.DEFAULT).build();
    return new Action.Builder().setIcon(icon).setOnClickListener(listener).build();
  }

  @Override public Template onGetTemplate() {
    NavigationTemplate.Builder template = new NavigationTemplate.Builder();
    try {
      ActionStrip.Builder strip = new ActionStrip.Builder();
      strip.addAction(new Action.Builder().setTitle("رجوع").setOnClickListener(() -> goBackFromCar()).build());
      strip.addAction(iconAction(R.drawable.ic_car_home, () -> goHomeFromCar()));
      strip.addAction(iconAction(R.drawable.ic_car_up, () -> pageScroll(-1)));
      strip.addAction(iconAction(R.drawable.ic_car_down, () -> pageScroll(1)));
      template.setActionStrip(strip.build());
    } catch (RuntimeException e) {
      Log.e("AmeerCarWeb", "Full action strip rejected, using back only", e);
      template.setActionStrip(new ActionStrip.Builder().addAction(
          new Action.Builder().setTitle("رجوع").setOnClickListener(() -> goBackFromCar()).build()).build());
    }
    try {
      if (getCarContext().getCarAppApiLevel() >= 2) {
        template.setMapActionStrip(new ActionStrip.Builder().addAction(Action.PAN).build());
      }
    } catch (RuntimeException e) { Log.e("AmeerCarWeb", "Map action strip rejected", e); }
    return template.build();
  }

final class CarBridge {
  private final CarContext context;
  private final WebView web;
  private final Handler main;
  private final PlayerView playerView;
  private ExoPlayer carPlayer;
  CarBridge(CarContext c, WebView w, Handler h, PlayerView p) {
    context = c; web = w; main = h; playerView = p;
  }

  @JavascriptInterface public String deviceId() {
    String id = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    return id == null ? "UNKNOWN" : id.toUpperCase();
  }
  @JavascriptInterface public void copy(String value) {
    ClipboardManager cm = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
    cm.setPrimaryClip(ClipData.newPlainText("Ameer Screens", value));
  }
  void openWebOnCar(String url) {
    main.post(() -> { try { if (web != null) web.loadUrl(url); } catch (Exception ignored) {} });
  }
  @JavascriptInterface public void openWeb(String url) {
    openWebOnCar(url);
  }
  @JavascriptInterface public String fetchText(String address) {
    java.net.HttpURLConnection connection = null;
    try {
      java.net.URL u = new java.net.URL(address);
      connection = (java.net.HttpURLConnection) u.openConnection();
      connection.setConnectTimeout(12000); connection.setReadTimeout(20000);
      connection.setRequestProperty("User-Agent", "AmeerScreens/1.0");
      java.io.InputStream in = connection.getInputStream();
      java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
      byte[] buffer = new byte[8192]; int count; int total = 0;
      while ((count = in.read(buffer)) != -1 && total < 5000000) { out.write(buffer,0,count); total += count; }
      in.close();
      return new String(out.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
    } catch (Exception e) { return ""; }
    finally { if (connection != null) connection.disconnect(); }
  }
  @JavascriptInterface public void openApp(String pkg) {
    if ("com.waze".equals(pkg) || "com.google.android.apps.maps".equals(pkg)) {
      try {
        Intent nav = new Intent(CarContext.ACTION_NAVIGATE, Uri.parse("geo:0,0?q=My%20Location"));
        // Let Android Auto choose the active navigation app; explicit package targeting is not supported here.
        context.startCarApp(nav);
        return;
      } catch (Exception ignored) {}
    }
    try {
      Intent i = context.getPackageManager().getLaunchIntentForPackage(pkg);
      if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i); }
    } catch (Exception ignored) {}
  }
  @JavascriptInterface public void saveMapApps(String json) {
    context.getSharedPreferences("ameer_maps", 0).edit().putString("apps", json).apply();
  }
  @JavascriptInterface public String listApps() {
    JSONArray out = new JSONArray();
    try {
      Intent q = new Intent(Intent.ACTION_MAIN); q.addCategory(Intent.CATEGORY_LAUNCHER);
      for (ResolveInfo r : context.getPackageManager().queryIntentActivities(q, 0)) {
        JSONObject o = new JSONObject(); o.put("n", r.loadLabel(context.getPackageManager()).toString());
        o.put("p", r.activityInfo.packageName); out.put(o);
      }
    } catch (Exception ignored) {}
    return out.toString();
  }
  @JavascriptInterface public boolean isCar() { return true; }

  private boolean hasMediaPermission() {
    String[] need = Build.VERSION.SDK_INT >= 33
        ? new String[]{"android.permission.READ_MEDIA_AUDIO", "android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_IMAGES"}
        : new String[]{"android.permission.READ_EXTERNAL_STORAGE"};
    for (String p : need) if (context.checkSelfPermission(p) != android.content.pm.PackageManager.PERMISSION_GRANTED) return false;
    return true;
  }

  @JavascriptInterface public void requestMediaPermission() {
    try {
      Intent i = new Intent(context, MainActivity.class);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
      i.putExtra("ameer_request_perm", true);
      context.startActivity(i);
    } catch (Exception e) { Log.e("AmeerCarWeb", "Unable to request media permission", e); }
  }

  @JavascriptInterface public String listMedia(String kind) {
    if (!hasMediaPermission()) return "PERM";
    JSONArray out = new JSONArray();
    try {
      Uri base = "audio".equals(kind) ? MediaStore.Audio.Media.EXTERNAL_CONTENT_URI :
          ("video".equals(kind) ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
      String name = MediaStore.MediaColumns.DISPLAY_NAME;
      Cursor c = context.getContentResolver().query(base, new String[]{MediaStore.MediaColumns._ID, name},
          null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC");
      if (c != null) {
        int n = 0;
        while (c.moveToNext() && n++ < 300) {
          JSONObject o = new JSONObject(); o.put("n", c.getString(1));
          o.put("u", Uri.withAppendedPath(base, c.getString(0)).toString()); out.put(o);
        }
        c.close();
      }
    } catch (Exception ignored) {}
    return out.toString();
  }
  
  @JavascriptInterface public void pickM3uFile() {
    try {
      Intent i = new Intent(context, MainActivity.class);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
      i.putExtra("ameer_pick_m3u", true);
      context.startActivity(i);
    } catch (Exception e) { Log.e("AmeerCarWeb", "Unable to open M3U picker", e); }
  }
  @JavascriptInterface public String consumeM3u() {
    android.content.SharedPreferences p = context.getSharedPreferences("ameer_m3u", 0);
    String value = p.getString("pending", "");
    if (value != null && !value.isEmpty()) p.edit().remove("pending").apply();
    return value == null ? "" : value;
  }
  
            @JavascriptInterface public String folders() { return context.getSharedPreferences("f", 0).getString("l", "[]"); }
  @JavascriptInterface public void removeFolder(String t) {
    try {
      JSONArray a = new JSONArray(folders()), n = new JSONArray();
      for (int i=0;i<a.length();i++) if (!a.getJSONObject(i).optString("t").equals(t)) n.put(a.getJSONObject(i));
      context.getSharedPreferences("f",0).edit().putString("l",n.toString()).apply();
    } catch (Exception ignored) {}
  }
  @JavascriptInterface public String listDir(String tree, String doc) {
    JSONArray out = new JSONArray();
    android.database.Cursor cursor = null;
    try {
      Uri treeUri = Uri.parse(tree);
      String parentId = (doc == null || doc.length() == 0)
          ? android.provider.DocumentsContract.getTreeDocumentId(treeUri) : doc;
      Uri parentUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, parentId);
      cursor = context.getContentResolver().query(
          android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId),
          new String[] {
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE,
            android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED
          }, null, null, null);
      if (cursor != null) {
        while (cursor.moveToNext() && out.length() < 1000) {
          String id = cursor.getString(0);
          String name = cursor.getString(1);
          String mime = cursor.getString(2);
          boolean directory = android.provider.DocumentsContract.Document.MIME_TYPE_DIR.equals(mime);
          Uri child = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
          JSONObject item = new JSONObject();
          item.put("id", id == null ? "" : id);
          item.put("n", name == null ? "بدون اسم" : name);
          item.put("d", directory);
          item.put("m", directory ? "vnd.android.document/directory" : (mime == null ? "application/octet-stream" : mime));
          item.put("u", directory ? "" : child.toString());
          item.put("t", cursor.isNull(3) ? 0 : cursor.getLong(3));
          out.put(item);
        }
      }
    } catch (Exception e) {
      android.util.Log.e("AmeerCarWeb", "Folder listing failed", e);
    } finally {
      if (cursor != null) try { cursor.close(); } catch (Exception ignored) {}
    }
    return out.toString();
  }
  @JavascriptInterface public void pickFolder() {
    Intent i = new Intent(context, MainActivity.class);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    i.putExtra("ameer_pick_folder", true); context.startActivity(i);
  }
  @JavascriptInterface public void playVideo(String url) {
    if (url == null || url.trim().isEmpty()) return;
    final String mediaUrl = url.trim();
    main.post(() -> {
      try {
        if (playerView == null || web == null) throw new IllegalStateException("Car display is not ready");
        if (carPlayer != null) { carPlayer.release(); carPlayer = null; }
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
            .setUserAgent("AmeerScreens/1.0 AndroidAuto")
            .setAllowCrossProtocolRedirects(true);
        DefaultDataSource.Factory data = new DefaultDataSource.Factory(context, http);
        DefaultMediaSourceFactory sources = new DefaultMediaSourceFactory(data);
        carPlayer = new ExoPlayer.Builder(context).setMediaSourceFactory(sources).build();
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setPlayer(carPlayer);
        carPlayer.setAudioAttributes(new AudioAttributes.Builder()                      .setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true);
        carPlayer.addListener(new Player.Listener() {                    @Override public void onPlayerError(PlaybackException error) {                      Toast.makeText(context, "تعذّر تشغيل القناة أو الفيديو: " + error.getErrorCodeName(), Toast.LENGTH_LONG).show();                      Log.e("AmeerCarWeb", "Media3 playback error", error);                    }
        });
        web.setVisibility(View.GONE);
        playerView.setVisibility(View.VISIBLE);
        carPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(mediaUrl)));
        carPlayer.prepare();
        carPlayer.play();
      } catch (Exception e) {
        Log.e("AmeerCarWeb", "In-car playback failed", e);
        Toast.makeText(context, "تعذّر تشغيل الفيديو على شاشة السيارة", Toast.LENGTH_LONG).show();
      }
    });
  }
  boolean hidePlayerIfVisible() {
    if (playerView == null || playerView.getVisibility() != View.VISIBLE) return false;
    try { if (carPlayer != null) carPlayer.pause(); } catch (Exception ignored) {}
    playerView.setVisibility(View.GONE);
    if (web != null) web.setVisibility(View.VISIBLE);
    return true;
  }
  @JavascriptInterface public void hidePlayer() {
    main.post(() -> {
      try { if (carPlayer != null) carPlayer.pause(); } catch (Exception ignored) {}
      if (playerView != null) playerView.setVisibility(View.GONE);
      if (web != null) web.setVisibility(View.VISIBLE);
    });
  }
  void release() {
    main.post(() -> {
      try { if (carPlayer != null) { carPlayer.release(); carPlayer = null; } } catch (Exception ignored) {}
      try { if (playerView != null) playerView.setPlayer(null); } catch (Exception ignored) {}
    });
  }
              @JavascriptInterface public String pollRemoteCommand() {
    android.content.SharedPreferences prefs = context.getSharedPreferences("ameer_remote", 0);
    String command = prefs.getString("pending", "");
    if (command != null && command.length() > 0) prefs.edit().remove("pending").apply();
    return command == null ? "" : command;
  }

@JavascriptInterface public void view(String uri, String mime) {
    try { Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(Uri.parse(uri), mime == null || mime.isEmpty() ? "*/*" : mime); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION); context.startActivity(i); } catch (Exception ignored) {}
  }
}
          }
